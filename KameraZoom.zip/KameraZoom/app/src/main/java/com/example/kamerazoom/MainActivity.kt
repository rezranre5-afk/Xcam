package com.example.kamerazoom

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.example.kamerazoom.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.min

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null

    private var liveRecording: Recording? = null   // klip singkat untuk Foto Live
    private var videoRecording: Recording? = null  // rekaman video biasa / cinema
    private var recStart = 0L

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // Mode dan pengaturan
    private var mode = MODE_PHOTO
    private var flashOn = false
    private var liveOn = true
    private var enhanceOn = true
    private var telescope = false
    private var useFront = false

    // Zoom total yang diminta user, relatif terhadap lensa yang sedang aktif.
    // Sebagian dipenuhi zoom hardware kamera, sisanya digital (crop).
    private var userZoom = 1f
    private var minZoom = 1f    // batas bawah zoom pada lensa aktif
    private var swFactor = 1f   // faktor zoom digital tambahan di atas zoom hardware
    private var touchInPreview = false

    // Info lensa
    private var mainId: String? = null          // id kamera utama (default)
    private var wideId: String? = null          // id lensa ultra-wide fisik (kalau ada)
    private var wideRatio = 1f                  // setara berapa x dibanding kamera utama
    private var currentLensId: String? = null   // null = kamera utama default
    private var lensRatio = 1f                  // pengali label zoom (1 utama, wideRatio ultra-wide)
    private var logicalMin = 1f                 // zoom minimum kamera utama (<1 kalau ultra-wide digabung)

    // Hasil terakhir (untuk thumbnail)
    private var lastUri: Uri? = null
    private var lastMime: String? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) {
            startCamera()
        } else {
            Toast.makeText(this, "Izin kamera dibutuhkan", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    /** Kemampuan kamera yang kita pakai untuk kualitas dan stabilizer. */
    private class Caps(
        val eis: Boolean,
        val ois: Boolean,
        val edgeHq: Boolean,
        val nrHq: Boolean,
        val fps24: Range<Int>?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupControls()
        setupGestures()
        updateModeUi()
        updateFlashUi()
        updateLiveUi()
        updateTelescopeUi()
        updateHdUi()

        val camGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (camGranted) {
            startCamera()
        } else {
            permLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    private fun videoLike() = mode != MODE_PHOTO

    // ---------------------------------------------------------------- UI

    private fun setupControls() {
        binding.shutterButton.setOnClickListener {
            if (videoLike()) toggleVideo() else capture()
        }
        binding.btnFlip.setOnClickListener { flipCamera() }
        binding.btnFlash.setOnClickListener {
            flashOn = !flashOn
            updateFlashUi()
            applyFlash()
        }
        binding.btnLive.setOnClickListener {
            if (videoCapture == null) {
                setStatus("HP ini tidak mendukung Live")
            } else {
                liveOn = !liveOn
                updateLiveUi()
            }
        }
        binding.btnHd.setOnClickListener {
            enhanceOn = !enhanceOn
            updateHdUi()
            setStatus(if (enhanceOn) "HD+ aktif: foto dipertajam otomatis" else "HD+ mati: foto asli kamera")
        }
        binding.modePhoto.setOnClickListener { setMode(MODE_PHOTO) }
        binding.modeVideo.setOnClickListener { setMode(MODE_VIDEO) }
        binding.modeCinema.setOnClickListener { setMode(MODE_CINEMA) }
        binding.thumbView.setOnClickListener { openLast() }

        binding.btnWide.setOnClickListener {
            if (isRecordingAnything()) return@setOnClickListener
            if (logicalMin < 0.95f) {
                // Ultra-wide digabung ke kamera utama oleh sistem
                if (onWideLens()) bindLens(null, logicalMin) else applyZoom(minZoom)
            } else if (wideId != null) {
                bindLens(wideId, 1f)
            }
        }
        binding.btnOne.setOnClickListener { gotoZoom(1f) }
        binding.btnTwo.setOnClickListener { gotoZoom(2f) }
        binding.btnFive.setOnClickListener { gotoZoom(5f) }
        binding.btnTen.setOnClickListener { gotoZoom(10f) }
        binding.btnTwenty.setOnClickListener { gotoZoom(20f) }
        binding.btnThirtyFive.setOnClickListener { gotoZoom(35f) }

        binding.telescopePill.setOnClickListener {
            telescope = !telescope
            updateTelescopeUi()
            if (telescope) {
                gotoZoom(MAX_ZOOM)
                Toast.makeText(
                    this,
                    "Telescope: zoom maks + penajaman kuat",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    applyZoom(userZoom * detector.scaleFactor)
                    return true
                }
            }
        )
        val tapDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent) = true
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    focusAt(e.x, e.y)
                    return true
                }
            }
        )

        binding.root.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                touchInPreview = ev.y >= binding.previewContainer.top &&
                    ev.y <= binding.previewContainer.bottom
            }
            if (touchInPreview) {
                scaleDetector.onTouchEvent(ev)
                tapDetector.onTouchEvent(ev)
            }
            true
        }
    }

    private fun setStatus(text: String) {
        binding.statusLabel.text = text
        binding.statusLabel.visibility = View.VISIBLE
        handler.removeCallbacks(hideStatus)
        handler.postDelayed(hideStatus, 3500)
    }

    private val hideStatus = Runnable { binding.statusLabel.visibility = View.GONE }

    private fun isRecordingAnything() = videoRecording != null || liveRecording != null

    private fun updateModeUi() {
        binding.modePhoto.setTextColor(if (mode == MODE_PHOTO) YELLOW else Color.WHITE)
        binding.modeVideo.setTextColor(if (mode == MODE_VIDEO) YELLOW else Color.WHITE)
        binding.modeCinema.setTextColor(if (mode == MODE_CINEMA) YELLOW else Color.WHITE)
        binding.shutterButton.setBackgroundResource(
            if (videoLike()) R.drawable.shutter_video else R.drawable.shutter_bg
        )
        val photoOnly = if (videoLike()) View.INVISIBLE else View.VISIBLE
        binding.btnLive.visibility = photoOnly
        binding.telescopePill.visibility = photoOnly
        binding.btnHd.visibility = photoOnly
        if (!videoLike()) binding.infoLabel.visibility = View.GONE
    }

    private fun updateFlashUi() {
        binding.btnFlash.setColorFilter(if (flashOn) YELLOW else Color.WHITE)
    }

    private fun updateLiveUi() {
        val supported = videoCapture != null
        binding.btnLive.setColorFilter(if (liveOn && supported) YELLOW else Color.WHITE)
        binding.btnLive.alpha = if (supported) 1f else 0.4f
    }

    private fun updateTelescopeUi() {
        binding.telescopePill.setTextColor(if (telescope) YELLOW else Color.WHITE)
    }

    private fun updateHdUi() {
        binding.btnHd.setTextColor(if (enhanceOn) YELLOW else Color.WHITE)
    }

    private fun setMode(newMode: Int) {
        if (isRecordingAnything() || newMode == mode) return
        mode = newMode
        updateModeUi()
        // Pengaturan stabilizer dan fps berbeda per mode, jadi kamera di-bind ulang
        if (cameraProvider != null) bindLens(currentLensId, userZoom) else applyZoom(userZoom)
    }

    private fun applyFlash() {
        imageCapture?.flashMode =
            if (flashOn && !videoLike()) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        try {
            camera?.cameraControl?.enableTorch(flashOn && videoLike())
        } catch (e: Exception) {
            // Kamera tanpa lampu: abaikan
        }
    }

    private fun updateChips() {
        val shown = userZoom * lensRatio
        val wideValue = if (logicalMin < 0.95f) logicalMin else wideRatio
        val chips: List<Pair<TextView, Float>> = listOf(
            binding.btnWide to wideValue,
            binding.btnOne to 1f,
            binding.btnTwo to 2f,
            binding.btnFive to 5f,
            binding.btnTen to 10f,
            binding.btnTwenty to 20f,
            binding.btnThirtyFive to 35f
        )
        var best: TextView? = null
        var bestDiff = Float.MAX_VALUE
        for ((v, value) in chips) {
            if (v.visibility != View.VISIBLE) continue
            val d = abs(ln(shown / value))
            if (d < bestDiff) {
                bestDiff = d
                best = v
            }
        }
        for ((v, _) in chips) {
            v.setTextColor(Color.WHITE)
            v.setTypeface(null, Typeface.NORMAL)
        }
        if (best != null && bestDiff < 0.1f) {
            best.setTextColor(YELLOW)
            best.setTypeface(null, Typeface.BOLD)
        }
    }

    // ---------------------------------------------------------------- Kamera

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider
            discoverLenses(provider)
            bindLens(null, 1f)
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Cari lensa ultra-wide fisik. Hanya berhasil kalau HP mengekspos kamera
     * belakang tambahan ke aplikasi (tidak semua HP melakukannya).
     */
    private fun discoverLenses(provider: ProcessCameraProvider) {
        try {
            val backs = CameraSelector.DEFAULT_BACK_CAMERA.filter(provider.availableCameraInfos)
            if (backs.isEmpty()) return

            fun spread(info: CameraInfo): Float? {
                val c2 = Camera2CameraInfo.from(info)
                val focal = c2.getCameraCharacteristic(
                    CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS
                )?.firstOrNull()
                val sensorW = c2.getCameraCharacteristic(
                    CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE
                )?.width
                return if (focal != null && sensorW != null && sensorW > 0f) focal / sensorW else null
            }

            mainId = Camera2CameraInfo.from(backs[0]).cameraId
            val mainSpread = spread(backs[0]) ?: return

            for (info in backs.drop(1)) {
                val s = spread(info) ?: continue
                val ratio = s / mainSpread
                if (ratio < 0.8f && (wideId == null || ratio < wideRatio)) {
                    wideId = Camera2CameraInfo.from(info).cameraId
                    wideRatio = ratio
                }
            }
        } catch (e: Exception) {
            // Abaikan: lensa tambahan tidak tersedia
        }
    }

    /** Baca fitur kualitas dan stabilizer yang didukung kamera terpilih. */
    private fun readCaps(info: CameraInfo?): Caps {
        if (info == null) return Caps(false, false, false, false, null)
        return try {
            val c2 = Camera2CameraInfo.from(info)
            val eisModes = c2.getCameraCharacteristic(
                CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES
            )
            val oisModes = c2.getCameraCharacteristic(
                CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION
            )
            val edgeModes = c2.getCameraCharacteristic(
                CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES
            )
            val nrModes = c2.getCameraCharacteristic(
                CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES
            )
            val fpsRanges = c2.getCameraCharacteristic(
                CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES
            )
            val fps24 = fpsRanges?.filter { it.upper == 24 }?.maxByOrNull { it.lower }
                ?: fpsRanges?.filter { it.lower == 24 }?.minByOrNull { it.upper }
            Caps(
                eis = eisModes?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true,
                ois = oisModes?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true,
                edgeHq = edgeModes?.contains(CameraMetadata.EDGE_MODE_HIGH_QUALITY) == true,
                nrHq = nrModes?.contains(CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY) == true,
                fps24 = fps24
            )
        } catch (e: Exception) {
            Caps(false, false, false, false, null)
        }
    }

    private fun onWideLens(): Boolean = currentLensId != null && currentLensId == wideId

    private fun fmtZoom(v: Float) = String.format(Locale.US, "%.1fx", v)

    private fun flipCamera() {
        if (isRecordingAnything()) return
        useFront = !useFront
        bindLens(null, 1f)
    }

    /**
     * Bind use case kamera. withOptions = pasang stabilizer/kualitas lewat Camera2 interop,
     * withVideo = ikutkan use case video (untuk Live dan Video).
     */
    private fun tryBind(
        provider: ProcessCameraProvider,
        selector: CameraSelector,
        caps: Caps,
        withOptions: Boolean,
        withVideo: Boolean
    ): Boolean {
        return try {
            provider.unbindAll()

            val previewBuilder = Preview.Builder()
            val resolution = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                .build()
            val icBuilder = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(resolution)

            if (withOptions) {
                val pe = Camera2Interop.Extender(previewBuilder)
                val ie = Camera2Interop.Extender(icBuilder)
                if (videoLike()) {
                    // Video: pakai stabilizer elektronik kalau ada, kalau tidak yang optik
                    if (caps.eis) {
                        pe.setCaptureRequestOption(
                            CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE,
                            CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                        )
                    } else if (caps.ois) {
                        pe.setCaptureRequestOption(
                            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                            CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                        )
                    }
                    val fps = caps.fps24
                    if (mode == MODE_CINEMA && fps != null) {
                        pe.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fps)
                    }
                } else {
                    // Foto: stabilizer optik + pengolahan tepi dan noise kualitas tinggi
                    if (caps.ois) {
                        pe.setCaptureRequestOption(
                            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                            CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                        )
                        ie.setCaptureRequestOption(
                            CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE,
                            CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                        )
                    }
                    if (caps.edgeHq) {
                        ie.setCaptureRequestOption(
                            CaptureRequest.EDGE_MODE,
                            CameraMetadata.EDGE_MODE_HIGH_QUALITY
                        )
                    }
                    if (caps.nrHq) {
                        ie.setCaptureRequestOption(
                            CaptureRequest.NOISE_REDUCTION_MODE,
                            CameraMetadata.NOISE_REDUCTION_MODE_HIGH_QUALITY
                        )
                    }
                }
            }

            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val ic = icBuilder.build()

            if (withVideo) {
                val recorder = Recorder.Builder()
                    .setQualitySelector(
                        QualitySelector.fromOrderedList(
                            listOf(Quality.FHD, Quality.HD, Quality.SD),
                            FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                        )
                    )
                    .setTargetVideoEncodingBitRate(VIDEO_BITRATE)
                    .build()
                val vc = VideoCapture.withOutput(recorder)
                camera = provider.bindToLifecycle(this, selector, preview, ic, vc)
                videoCapture = vc
            } else {
                camera = provider.bindToLifecycle(this, selector, preview, ic)
                videoCapture = null
            }
            imageCapture = ic
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun bindLens(id: String?, zoomAfter: Float) {
        val provider = cameraProvider ?: return

        val selector = when {
            useFront -> CameraSelector.DEFAULT_FRONT_CAMERA
            id == null -> CameraSelector.DEFAULT_BACK_CAMERA
            else -> CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter { infos ->
                    infos.filter { Camera2CameraInfo.from(it).cameraId == id }
                }
                .build()
        }

        val caps = readCaps(selector.filter(provider.availableCameraInfos).firstOrNull())

        // Coba dari yang terlengkap, turun bertahap kalau HP tidak mendukung
        var bound = false
        var optionsUsed = false
        for ((opts, vid) in listOf(true to true, false to true, false to false)) {
            if (tryBind(provider, selector, caps, opts, vid)) {
                bound = true
                optionsUsed = opts
                break
            }
        }

        if (!bound) {
            Toast.makeText(this, "Lensa ini tidak bisa dipakai", Toast.LENGTH_LONG).show()
            if (id != null) bindLens(null, 1f)
            return
        }

        if (videoCapture == null) {
            if (videoLike()) {
                mode = MODE_PHOTO
                updateModeUi()
            }
            Toast.makeText(
                this, "HP ini tidak mendukung Live/video, foto biasa saja", Toast.LENGTH_LONG
            ).show()
        }

        currentLensId = if (useFront) null else id
        updateLiveUi()

        val st = camera?.cameraInfo?.zoomState?.value
        if (useFront) {
            minZoom = 1f
            lensRatio = 1f
        } else if (id == null) {
            logicalMin = (st?.minZoomRatio ?: 1f).coerceIn(0.4f, 1f)
            minZoom = logicalMin
            lensRatio = 1f
        } else {
            minZoom = 1f
            lensRatio = wideRatio
        }

        // Tombol ultra-wide: tampil kalau ada zoom <1 dari sistem atau lensa fisik terdeteksi
        val hasWide = !useFront && (logicalMin < 0.95f || wideId != null)
        binding.btnWide.visibility = if (hasWide) View.VISIBLE else View.GONE
        binding.btnWide.text = fmtZoom(if (logicalMin < 0.95f) logicalMin else wideRatio)

        updateInfoLabel(caps, optionsUsed)
        applyFlash()
        applyZoom(zoomAfter)
    }

    private fun updateInfoLabel(caps: Caps, optionsUsed: Boolean) {
        if (!videoLike()) {
            binding.infoLabel.visibility = View.GONE
            return
        }
        val stab = when {
            !optionsUsed -> "Stabilizer tidak aktif"
            caps.eis -> "Stabilizer EIS aktif"
            caps.ois -> "Stabilizer optik (OIS) aktif"
            else -> "HP ini tidak punya stabilizer"
        }
        val text = if (mode == MODE_CINEMA) {
            val fps = if (optionsUsed && caps.fps24 != null) "24 fps" else "24 fps tidak didukung"
            "CINEMA · $fps · $stab"
        } else {
            stab
        }
        binding.infoLabel.text = text
        binding.infoLabel.visibility = View.VISIBLE
    }

    /** Pindah ke zoom tertentu pada kamera utama (kembali dari lensa ultra-wide kalau perlu). */
    private fun gotoZoom(z: Float) {
        if (isRecordingAnything() && onWideLens()) return
        if (onWideLens()) bindLens(null, z) else applyZoom(z)
    }

    private fun applyZoom(total: Float) {
        val state = camera?.cameraInfo?.zoomState?.value
        val hwMax = state?.maxZoomRatio ?: 1f
        val hwMin = (state?.minZoomRatio ?: 1f).coerceAtMost(hwMax)

        // Video hanya memakai zoom hardware supaya hasil rekaman sama dengan pratinjau
        val maxAllowed = if (videoLike()) hwMax.coerceAtLeast(minZoom) else MAX_ZOOM
        if (videoLike() && total > maxAllowed * 1.01f) {
            setStatus("Video: zoom maks ${fmtZoom(maxAllowed * lensRatio)} (sesuai kamera)")
        }

        userZoom = total.coerceIn(minZoom, maxAllowed)
        val hw = userZoom.coerceIn(hwMin, hwMax)

        camera?.cameraControl?.setZoomRatio(hw)

        // Sisa zoom di atas kemampuan hardware dilakukan digital
        swFactor = (userZoom / hw).coerceAtLeast(1f)
        binding.previewView.scaleX = swFactor
        binding.previewView.scaleY = swFactor

        val digital = if (swFactor > 1.01f) "  ·  digital" else ""
        binding.zoomLabel.text = String.format(Locale.US, "%.1fx%s", userZoom * lensRatio, digital)

        updateChips()
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pv = binding.previewView
        // Koordinat sentuh relatif terhadap container pratinjau
        val px = x - binding.previewContainer.left
        val py = y - binding.previewContainer.top
        // Koreksi karena pratinjau di-scale (zoom digital)
        val cx = pv.width / 2f
        val cy = pv.height / 2f
        val lx = cx + (px - cx) / swFactor
        val ly = cy + (py - cy) / swFactor
        val point = pv.meteringPointFactory.createPoint(lx, ly)
        val action = FocusMeteringAction.Builder(point)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    // ---------------------------------------------------------------- Foto

    private fun capture() {
        val ic = imageCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val live = liveOn && videoCapture != null
        val sw = swFactor
        val needProcess = sw > 1.01f || telescope || enhanceOn

        if (needProcess) {
            captureProcessed(ic, stamp, live, sw)
        } else {
            captureOriginal(ic, stamp, live)
        }
    }

    /** HD+ mati dan tanpa zoom digital: simpan JPEG asli dari kamera tanpa diolah ulang. */
    private fun captureOriginal(ic: ImageCapture, stamp: String, live: Boolean) {
        val prefix = if (live) "LIVE_" else "IMG_"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$prefix$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraZoom")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()

        ic.takePicture(
            options,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    val uri = output.savedUri
                    if (uri != null) updateThumb(uri, "image/jpeg")
                    if (live) startLiveClip(stamp) else setStatus("Foto tersimpan ✓")
                }

                override fun onError(exception: ImageCaptureException) {
                    setStatus("Gagal jepret: ${exception.message}")
                }
            }
        )
    }

    /** Foto dengan zoom digital, Telescope, atau HD+: diolah dulu lalu disimpan. */
    private fun captureProcessed(ic: ImageCapture, stamp: String, live: Boolean, sw: Float) {
        val sharp = if (telescope) 0.9f else 0.5f
        val contrast = if (telescope) 1.08f else 1.05f

        ic.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val rot = image.imageInfo.rotationDegrees
                val raw: Bitmap = try {
                    image.toBitmap()
                } catch (t: Throwable) {
                    image.close()
                    runOnUiThread { setStatus("Gagal memproses foto") }
                    return
                }
                image.close()

                // Klip live dimulai SETELAH foto diambil supaya tidak bentrok
                runOnUiThread {
                    setStatus("Memproses foto…")
                    if (live) startLiveClip(stamp)
                }

                try {
                    var bmp = raw
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                        if (r !== bmp) bmp.recycle()
                        bmp = r
                    }
                    if (sw > 1.01f) {
                        val w = (bmp.width / sw).toInt().coerceAtLeast(2)
                        val h = (bmp.height / sw).toInt().coerceAtLeast(2)
                        val c = Bitmap.createBitmap(
                            bmp, (bmp.width - w) / 2, (bmp.height - h) / 2, w, h
                        )
                        if (c !== bmp) bmp.recycle()
                        bmp = c
                    }
                    // Lewati pengolahan untuk foto raksasa supaya memori aman
                    if ((enhanceOn || telescope) &&
                        bmp.width.toLong() * bmp.height <= MAX_ENHANCE_PIXELS
                    ) {
                        val e = enhance(bmp, sharp, contrast, 1.06f)
                        if (e !== bmp) bmp.recycle()
                        bmp = e
                    }
                    savePhoto(bmp, stamp, live)
                } catch (t: Throwable) {
                    runOnUiThread { setStatus("Gagal menyimpan foto") }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { setStatus("Gagal jepret: ${exception.message}") }
            }
        })
    }

    private fun savePhoto(bmp: Bitmap, stamp: String, live: Boolean) {
        val prefix = if (live) "LIVE_" else "IMG_"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$prefix$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraZoom")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            runOnUiThread { setStatus("Gagal menyimpan foto") }
            return
        }
        contentResolver.openOutputStream(uri)?.use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 98, it)
        }
        val info = "${bmp.width}×${bmp.height}"
        runOnUiThread { if (!live) setStatus("Foto tersimpan ✓  $info") }
        updateThumb(uri, "image/jpeg")
    }

    /**
     * Pertajam + sedikit kontras dan warna. Penajaman dikerjakan per pita baris
     * supaya memori tidak membengkak di foto beresolusi besar.
     */
    private fun enhance(src: Bitmap, sharp: Float, contrast: Float, saturation: Float): Bitmap {
        val w = src.width
        val h = src.height

        // 1) Kontras + saturasi lewat color matrix
        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply { setSaturation(saturation) }
        val t = (-0.5f * contrast + 0.5f) * 255f
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, t,
                    0f, contrast, 0f, 0f, t,
                    0f, 0f, contrast, 0f, t,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        Canvas(dst).drawBitmap(src, 0f, 0f, paint)

        if (w < 3 || h < 3) return dst

        // 2) Penajaman (laplacian 4 tetangga), per pita
        fun ch(shift: Int, c: Int, l: Int, r: Int, u: Int, d: Int): Int {
            val cc = (c shr shift) and 0xFF
            val sum = ((l shr shift) and 0xFF) + ((r shr shift) and 0xFF) +
                ((u shr shift) and 0xFF) + ((d shr shift) and 0xFF)
            return (cc + sharp * (4 * cc - sum)).toInt().coerceIn(0, 255)
        }

        val band = 64
        val buf = IntArray(w * (band + 1))
        val out = IntArray(w * band)
        var prev = IntArray(w)
        var y0 = 0
        while (y0 < h) {
            val rows = min(band, h - y0)
            val readRows = if (y0 + rows < h) rows + 1 else rows
            dst.getPixels(buf, 0, w, 0, y0, w, readRows)
            val newPrev = buf.copyOfRange((rows - 1) * w, rows * w)

            for (r in 0 until rows) {
                val rowBase = r * w
                for (x in 0 until w) {
                    val c = buf[rowBase + x]
                    val up = if (r == 0) {
                        if (y0 == 0) c else prev[x]
                    } else {
                        buf[rowBase - w + x]
                    }
                    val down = if (r + 1 < readRows) buf[rowBase + w + x] else c
                    val l = if (x > 0) buf[rowBase + x - 1] else c
                    val rt = if (x < w - 1) buf[rowBase + x + 1] else c
                    out[rowBase + x] = (0xFF shl 24) or
                        (ch(16, c, l, rt, up, down) shl 16) or
                        (ch(8, c, l, rt, up, down) shl 8) or
                        ch(0, c, l, rt, up, down)
                }
            }
            dst.setPixels(out, 0, w, 0, y0, w, rows)
            prev = newPrev
            y0 += rows
        }
        return dst
    }

    // ---------------------------------------------------------------- Live

    @SuppressLint("MissingPermission")
    private fun startLiveClip(stamp: String) {
        val vc = videoCapture ?: return
        if (isRecordingAnything()) return

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraZoom")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            var pending = vc.output.prepareRecording(this, options)
            if (audioGranted()) pending = pending.withAudioEnabled()

            liveRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    liveRecording = null
                    if (event.hasError()) {
                        setStatus("Klip live gagal (kode ${event.error})")
                    } else {
                        setStatus("Foto live tersimpan ✓")
                    }
                }
            }
            setStatus("Merekam live…")
            handler.postDelayed({ liveRecording?.stop() }, LIVE_MS)
        } catch (t: Throwable) {
            liveRecording = null
            setStatus("Klip live gagal: ${t.javaClass.simpleName}")
        }
    }

    // ---------------------------------------------------------------- Video

    private fun audioGranted() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun toggleVideo() {
        val active = videoRecording
        if (active != null) {
            active.stop()
        } else {
            startVideo()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startVideo() {
        val vc = videoCapture
        if (vc == null) {
            setStatus("HP ini tidak mendukung video")
            return
        }
        if (isRecordingAnything()) return

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val prefix = if (mode == MODE_CINEMA) "CIN_" else "VID_"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$prefix$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraZoom")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            var pending = vc.output.prepareRecording(this, options)
            if (audioGranted()) {
                pending = pending.withAudioEnabled()
            } else {
                setStatus("Tanpa suara: izin mikrofon belum diberikan")
            }

            videoRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    videoRecording = null
                    stopRecUi()
                    if (event.hasError()) {
                        setStatus("Video gagal (kode ${event.error})")
                    } else {
                        setStatus("Video tersimpan ✓")
                        updateThumb(event.outputResults.outputUri, "video/mp4")
                    }
                }
            }
            startRecUi()
        } catch (t: Throwable) {
            videoRecording = null
            setStatus("Video gagal: ${t.javaClass.simpleName}")
        }
    }

    private val recTick = object : Runnable {
        override fun run() {
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            binding.recLabel.text = String.format(Locale.US, "●  %02d:%02d", s / 60, s % 60)
            handler.postDelayed(this, 500)
        }
    }

    private fun startRecUi() {
        recStart = SystemClock.elapsedRealtime()
        binding.recLabel.visibility = View.VISIBLE
        binding.shutterButton.setBackgroundResource(R.drawable.shutter_recording)
        handler.post(recTick)
    }

    private fun stopRecUi() {
        handler.removeCallbacks(recTick)
        binding.recLabel.visibility = View.GONE
        binding.shutterButton.setBackgroundResource(R.drawable.shutter_video)
    }

    // ---------------------------------------------------------------- Thumbnail

    private fun updateThumb(uri: Uri, mime: String) {
        lastUri = uri
        lastMime = mime
        ioExecutor.execute {
            try {
                val thumb = contentResolver.loadThumbnail(uri, Size(240, 240), null)
                runOnUiThread { binding.thumbView.setImageBitmap(thumb) }
            } catch (t: Throwable) {
                // Thumbnail gagal dimuat: abaikan
            }
        }
    }

    private fun openLast() {
        val uri = lastUri ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, lastMime ?: "image/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: Exception) {
            setStatus("Tidak ada aplikasi galeri")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        liveRecording?.stop()
        videoRecording?.stop()
        ioExecutor.shutdown()
    }

    companion object {
        private const val MODE_PHOTO = 0
        private const val MODE_VIDEO = 1
        private const val MODE_CINEMA = 2

        private const val MAX_ZOOM = 35f
        private const val LIVE_MS = 3000L
        private const val VIDEO_BITRATE = 16_000_000
        private const val MAX_ENHANCE_PIXELS = 30_000_000L
        private val YELLOW = Color.parseColor("#FFD60A")
    }
}
