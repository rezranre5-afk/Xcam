package com.example.kamerazoom

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.example.kamerazoom.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.ln

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null

    private var liveRecording: Recording? = null   // klip singkat untuk Foto Live
    private var videoRecording: Recording? = null  // rekaman video biasa
    private var recStart = 0L

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // Mode dan pengaturan
    private var videoMode = false
    private var flashOn = false
    private var liveOn = true
    private var telescope = false
    private var useFront = false

    // Zoom total yang diminta user, relatif terhadap lensa yang sedang aktif.
    // Sebagian dipenuhi zoom hardware kamera, sisanya digital (crop).
    private var userZoom = 1f
    private var minZoom = 1f    // batas bawah zoom pada lensa aktif
    private var swFactor = 1f   // faktor zoom digital tambahan di atas zoom hardware
    private var touchInPreview = false

    // Info lensa
    private var mainId: String? = null          // id kamera utama (default)
    private var wideId: String? = null          // id lensa ultra-wide fisik (kalau ada)
    private var wideRatio = 1f                  // setara berapa x dibanding kamera utama
    private var currentLensId: String? = null   // null = kamera utama default
    private var lensRatio = 1f                  // pengali label zoom (1 utama, wideRatio ultra-wide)
    private var logicalMin = 1f                 // zoom minimum kamera utama (<1 kalau ultra-wide digabung)

    // Hasil terakhir (untuk thumbnail)
    private var lastUri: Uri? = null
    private var lastMime: String? = null

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) {
            startCamera()
        } else {
            Toast.makeText(this, "Izin kamera dibutuhkan", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupControls()
        setupGestures()
        updateModeUi()
        updateFlashUi()
        updateLiveUi()
        updateTelescopeUi()

        val camGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (camGranted) {
            startCamera()
        } else {
            permLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    // ---------------------------------------------------------------- UI

    private fun setupControls() {
        binding.shutterButton.setOnClickListener {
            if (videoMode) toggleVideo() else capture()
        }
        binding.btnFlip.setOnClickListener { flipCamera() }
        binding.btnFlash.setOnClickListener {
            flashOn = !flashOn
            updateFlashUi()
            applyFlash()
        }
        binding.btnLive.setOnClickListener {
            if (videoCapture == null) {
                setStatus("HP ini tidak mendukung Live")
            } else {
                liveOn = !liveOn
                updateLiveUi()
            }
        }
        binding.modePhoto.setOnClickListener { setMode(false) }
        binding.modeVideo.setOnClickListener { setMode(true) }
        binding.thumbView.setOnClickListener { openLast() }

        binding.btnWide.setOnClickListener {
            if (isRecordingAnything()) return@setOnClickListener
            if (logicalMin < 0.95f) {
                // Ultra-wide digabung ke kamera utama oleh sistem
                if (onWideLens()) bindLens(null, logicalMin) else applyZoom(minZoom)
            } else if (wideId != null) {
                bindLens(wideId, 1f)
            }
        }
        binding.btnOne.setOnClickListener { gotoZoom(1f) }
        binding.btnTwo.setOnClickListener { gotoZoom(2f) }
        binding.btnFive.setOnClickListener { gotoZoom(5f) }
        binding.btnTen.setOnClickListener { gotoZoom(10f) }
        binding.btnTwenty.setOnClickListener { gotoZoom(20f) }
        binding.btnThirtyFive.setOnClickListener { gotoZoom(35f) }

        binding.telescopePill.setOnClickListener {
            telescope = !telescope
            updateTelescopeUi()
            if (telescope) {
                gotoZoom(MAX_ZOOM)
                Toast.makeText(
                    this,
                    "Telescope: zoom maks + penajaman hasil foto",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    applyZoom(userZoom * detector.scaleFactor)
                    return true
                }
            }
        )
        val tapDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent) = true
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    focusAt(e.x, e.y)
                    return true
                }
            }
        )

        binding.root.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                touchInPreview = ev.y >= binding.previewContainer.top &&
                    ev.y <= binding.previewContainer.bottom
            }
            if (touchInPreview) {
                scaleDetector.onTouchEvent(ev)
                tapDetector.onTouchEvent(ev)
            }
            true
        }
    }

    private fun setStatus(text: String) {
        binding.statusLabel.text = text
        binding.statusLabel.visibility = View.VISIBLE
        handler.removeCallbacks(hideStatus)
        handler.postDelayed(hideStatus, 3500)
    }

    private val hideStatus = Runnable { binding.statusLabel.visibility = View.GONE }

    private fun isRecordingAnything() = videoRecording != null || liveRecording != null

    private fun updateModeUi() {
        binding.modePhoto.setTextColor(if (!videoMode) YELLOW else Color.WHITE)
        binding.modeVideo.setTextColor(if (videoMode) YELLOW else Color.WHITE)
        binding.shutterButton.setBackgroundResource(
            if (videoMode) R.drawable.shutter_video else R.drawable.shutter_bg
        )
        binding.btnLive.visibility = if (videoMode) View.INVISIBLE else View.VISIBLE
        binding.telescopePill.visibility = if (videoMode) View.INVISIBLE else View.VISIBLE
    }

    private fun updateFlashUi() {
        binding.btnFlash.setColorFilter(if (flashOn) YELLOW else Color.WHITE)
    }

    private fun updateLiveUi() {
        val supported = videoCapture != null
        binding.btnLive.setColorFilter(if (liveOn && supported) YELLOW else Color.WHITE)
        binding.btnLive.alpha = if (supported) 1f else 0.4f
    }

    private fun updateTelescopeUi() {
        binding.telescopePill.setTextColor(if (telescope) YELLOW else Color.WHITE)
    }

    private fun setMode(video: Boolean) {
        if (isRecordingAnything()) return
        videoMode = video
        updateModeUi()
        applyFlash()
        applyZoom(userZoom) // di mode video zoom dibatasi zoom hardware
    }

    private fun applyFlash() {
        imageCapture?.flashMode =
            if (flashOn && !videoMode) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        try {
            camera?.cameraControl?.enableTorch(flashOn && videoMode)
        } catch (e: Exception) {
            // Kamera tanpa lampu: abaikan
        }
    }

    private fun updateChips() {
        val shown = userZoom * lensRatio
        val wideValue = if (logicalMin < 0.95f) logicalMin else wideRatio
        val chips: List<Pair<TextView, Float>> = listOf(
            binding.btnWide to wideValue,
            binding.btnOne to 1f,
            binding.btnTwo to 2f,
            binding.btnFive to 5f,
            binding.btnTen to 10f,
            binding.btnTwenty to 20f,
            binding.btnThirtyFive to 35f
        )
        var best: TextView? = null
        var bestDiff = Float.MAX_VALUE
        for ((v, value) in chips) {
            if (v.visibility != View.VISIBLE) continue
            val d = abs(ln(shown / value))
            if (d < bestDiff) {
                bestDiff = d
                best = v
            }
        }
        for ((v, _) in chips) {
            v.setTextColor(Color.WHITE)
            v.setTypeface(null, Typeface.NORMAL)
        }
        if (best != null && bestDiff < 0.1f) {
            best.setTextColor(YELLOW)
            best.setTypeface(null, Typeface.BOLD)
        }
    }

    // ---------------------------------------------------------------- Kamera

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider
            discoverLenses(provider)
            bindLens(null, 1f)
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Cari lensa ultra-wide fisik. Hanya berhasil kalau HP mengekspos kamera
     * belakang tambahan ke aplikasi (tidak semua HP melakukannya).
     */
    private fun discoverLenses(provider: ProcessCameraProvider) {
        try {
            val backs = CameraSelector.DEFAULT_BACK_CAMERA.filter(provider.availableCameraInfos)
            if (backs.isEmpty()) return

            fun spread(info: CameraInfo): Float? {
                val c2 = Camera2CameraInfo.from(info)
                val focal = c2.getCameraCharacteristic(
                    CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS
                )?.firstOrNull()
                val sensorW = c2.getCameraCharacteristic(
                    CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE
                )?.width
                return if (focal != null && sensorW != null && sensorW > 0f) focal / sensorW else null
            }

            mainId = Camera2CameraInfo.from(backs[0]).cameraId
            val mainSpread = spread(backs[0]) ?: return

            for (info in backs.drop(1)) {
                val s = spread(info) ?: continue
                val ratio = s / mainSpread
                if (ratio < 0.8f && (wideId == null || ratio < wideRatio)) {
                    wideId = Camera2CameraInfo.from(info).cameraId
                    wideRatio = ratio
                }
            }
        } catch (e: Exception) {
            // Abaikan: lensa tambahan tidak tersedia
        }
    }

    private fun onWideLens(): Boolean = currentLensId != null && currentLensId == wideId

    private fun fmtZoom(v: Float) = String.format(Locale.US, "%.1fx", v)

    private fun flipCamera() {
        if (isRecordingAnything()) return
        useFront = !useFront
        bindLens(null, 1f)
    }

    private fun bindLens(id: String?, zoomAfter: Float) {
        val provider = cameraProvider ?: return

        val selector = when {
            useFront -> CameraSelector.DEFAULT_FRONT_CAMERA
            id == null -> CameraSelector.DEFAULT_BACK_CAMERA
            else -> CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .addCameraFilter { infos ->
                    infos.filter { Camera2CameraInfo.from(it).cameraId == id }
                }
                .build()
        }

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(binding.previewView.surfaceProvider)
        }
        val ic = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
        val recorder = Recorder.Builder()
            .setQualitySelector(
                QualitySelector.from(
                    Quality.FHD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                )
            )
            .build()
        val vc = VideoCapture.withOutput(recorder)

        provider.unbindAll()

        var bound = false
        try {
            camera = provider.bindToLifecycle(this, selector, preview, ic, vc)
            videoCapture = vc
            bound = true
        } catch (e: Exception) {
            // lanjut ke fallback
        }

        if (!bound) {
            // HP tidak mendukung foto + video barengan -> fallback foto saja
            provider.unbindAll()
            try {
                camera = provider.bindToLifecycle(this, selector, preview, ic)
                videoCapture = null
                if (videoMode) {
                    videoMode = false
                    updateModeUi()
                }
                Toast.makeText(
                    this, "HP ini tidak mendukung Live/video, foto biasa saja", Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Lensa ini tidak bisa dipakai", Toast.LENGTH_LONG).show()
                if (id != null) bindLens(null, 1f)
                return
            }
        }

        imageCapture = ic
        currentLensId = if (useFront) null else id
        updateLiveUi()

        val st = camera?.cameraInfo?.zoomState?.value
        if (useFront) {
            minZoom = 1f
            lensRatio = 1f
        } else if (id == null) {
            logicalMin = (st?.minZoomRatio ?: 1f).coerceIn(0.4f, 1f)
            minZoom = logicalMin
            lensRatio = 1f
        } else {
            minZoom = 1f
            lensRatio = wideRatio
        }

        // Tombol ultra-wide: tampil kalau ada zoom <1 dari sistem atau lensa fisik terdeteksi
        val hasWide = !useFront && (logicalMin < 0.95f || wideId != null)
        binding.btnWide.visibility = if (hasWide) View.VISIBLE else View.GONE
        binding.btnWide.text = fmtZoom(if (logicalMin < 0.95f) logicalMin else wideRatio)

        applyFlash()
        applyZoom(zoomAfter)
    }

    /** Pindah ke zoom tertentu pada kamera utama (kembali dari lensa ultra-wide kalau perlu). */
    private fun gotoZoom(z: Float) {
        if (isRecordingAnything() && onWideLens()) return
        if (onWideLens()) bindLens(null, z) else applyZoom(z)
    }

    private fun applyZoom(total: Float) {
        val state = camera?.cameraInfo?.zoomState?.value
        val hwMax = state?.maxZoomRatio ?: 1f
        val hwMin = (state?.minZoomRatio ?: 1f).coerceAtMost(hwMax)

        // Video hanya memakai zoom hardware supaya hasil rekaman sama dengan pratinjau
        val maxAllowed = if (videoMode) hwMax.coerceAtLeast(minZoom) else MAX_ZOOM
        if (videoMode && total > maxAllowed * 1.01f) {
            setStatus("Video: zoom maks ${fmtZoom(maxAllowed * lensRatio)} (sesuai kamera)")
        }

        userZoom = total.coerceIn(minZoom, maxAllowed)
        val hw = userZoom.coerceIn(hwMin, hwMax)

        camera?.cameraControl?.setZoomRatio(hw)

        // Sisa zoom di atas kemampuan hardware dilakukan digital
        swFactor = (userZoom / hw).coerceAtLeast(1f)
        binding.previewView.scaleX = swFactor
        binding.previewView.scaleY = swFactor

        val digital = if (swFactor > 1.01f) "  ·  digital" else ""
        binding.zoomLabel.text = String.format(Locale.US, "%.1fx%s", userZoom * lensRatio, digital)

        updateChips()
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pv = binding.previewView
        // Koordinat sentuh relatif terhadap container pratinjau
        val px = x - binding.previewContainer.left
        val py = y - binding.previewContainer.top
        // Koreksi karena pratinjau di-scale (zoom digital)
        val cx = pv.width / 2f
        val cy = pv.height / 2f
        val lx = cx + (px - cx) / swFactor
        val ly = cy + (py - cy) / swFactor
        val point = pv.meteringPointFactory.createPoint(lx, ly)
        val action = FocusMeteringAction.Builder(point)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    // ---------------------------------------------------------------- Foto

    private fun capture() {
        val ic = imageCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val live = liveOn && videoCapture != null
        val sw = swFactor
        val sharpenOn = telescope

        ic.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val rot = image.imageInfo.rotationDegrees
                val raw: Bitmap = try {
                    image.toBitmap()
                } catch (t: Throwable) {
                    image.close()
                    runOnUiThread { setStatus("Gagal memproses foto") }
                    return
                }
                image.close()

                // Klip live dimulai SETELAH foto diambil supaya tidak bentrok
                if (live) runOnUiThread { startLiveClip(stamp) }

                try {
                    var bmp = raw
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    if (sw > 1.01f) {
                        val w = (bmp.width / sw).toInt().coerceAtLeast(2)
                        val h = (bmp.height / sw).toInt().coerceAtLeast(2)
                        bmp = Bitmap.createBitmap(
                            bmp, (bmp.width - w) / 2, (bmp.height - h) / 2, w, h
                        )
                    }
                    if (sharpenOn) bmp = sharpen(bmp)
                    savePhoto(bmp, stamp, live)
                } catch (t: Throwable) {
                    runOnUiThread { setStatus("Gagal menyimpan foto") }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { setStatus("Gagal jepret: ${exception.message}") }
            }
        })
    }

    private fun savePhoto(bmp: Bitmap, stamp: String, live: Boolean) {
        val prefix = if (live) "LIVE_" else "IMG_"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$prefix$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraZoom")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            runOnUiThread { setStatus("Gagal menyimpan foto") }
            return
        }
        contentResolver.openOutputStream(uri)?.use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)
        }
        runOnUiThread { if (!live) setStatus("Foto tersimpan ✓") }
        updateThumb(uri, "image/jpeg")
    }

    // ---------------------------------------------------------------- Live

    @SuppressLint("MissingPermission")
    private fun startLiveClip(stamp: String) {
        val vc = videoCapture ?: return
        if (isRecordingAnything()) return

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraZoom")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            var pending = vc.output.prepareRecording(this, options)
            if (audioGranted()) pending = pending.withAudioEnabled()

            liveRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    liveRecording = null
                    if (event.hasError()) {
                        setStatus("Klip live gagal (kode ${event.error})")
                    } else {
                        setStatus("Foto live tersimpan ✓")
                    }
                }
            }
            setStatus("Merekam live…")
            handler.postDelayed({ liveRecording?.stop() }, LIVE_MS)
        } catch (t: Throwable) {
            liveRecording = null
            setStatus("Klip live gagal: ${t.javaClass.simpleName}")
        }
    }

    // ---------------------------------------------------------------- Video

    private fun audioGranted() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    private fun toggleVideo() {
        val active = videoRecording
        if (active != null) {
            active.stop()
        } else {
            startVideo()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startVideo() {
        val vc = videoCapture
        if (vc == null) {
            setStatus("HP ini tidak mendukung video")
            return
        }
        if (isRecordingAnything()) return

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraZoom")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            var pending = vc.output.prepareRecording(this, options)
            if (audioGranted()) {
                pending = pending.withAudioEnabled()
            } else {
                setStatus("Tanpa suara: izin mikrofon belum diberikan")
            }

            videoRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
                if (event is VideoRecordEvent.Finalize) {
                    videoRecording = null
                    stopRecUi()
                    if (event.hasError()) {
                        setStatus("Video gagal (kode ${event.error})")
                    } else {
                        setStatus("Video tersimpan ✓")
                        updateThumb(event.outputResults.outputUri, "video/mp4")
                    }
                }
            }
            startRecUi()
        } catch (t: Throwable) {
            videoRecording = null
            setStatus("Video gagal: ${t.javaClass.simpleName}")
        }
    }

    private val recTick = object : Runnable {
        override fun run() {
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            binding.recLabel.text = String.format(Locale.US, "●  %02d:%02d", s / 60, s % 60)
            handler.postDelayed(this, 500)
        }
    }

    private fun startRecUi() {
        recStart = SystemClock.elapsedRealtime()
        binding.recLabel.visibility = View.VISIBLE
        binding.shutterButton.setBackgroundResource(R.drawable.shutter_recording)
        handler.post(recTick)
    }

    private fun stopRecUi() {
        handler.removeCallbacks(recTick)
        binding.recLabel.visibility = View.GONE
        binding.shutterButton.setBackgroundResource(R.drawable.shutter_video)
    }

    // ---------------------------------------------------------------- Thumbnail

    private fun updateThumb(uri: Uri, mime: String) {
        lastUri = uri
        lastMime = mime
        ioExecutor.execute {
            try {
                val thumb = contentResolver.loadThumbnail(uri, Size(240, 240), null)
                runOnUiThread { binding.thumbView.setImageBitmap(thumb) }
            } catch (t: Throwable) {
                // Thumbnail gagal dimuat: abaikan
            }
        }
    }

    private fun openLast() {
        val uri = lastUri ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, lastMime ?: "image/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: Exception) {
            setStatus("Tidak ada aplikasi galeri")
        }
    }

    // ---------------------------------------------------------------- Telescope

    /** Penajaman sederhana (laplacian 4 tetangga) supaya hasil zoom tinggi lebih tegas. */
    private fun sharpen(src: Bitmap, amount: Float = 0.7f): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 3 || h < 3) return src

        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val out = px.copyOf()

        fun sc(shift: Int, c: Int, l: Int, r: Int, u: Int, d: Int): Int {
            val cc = (c shr shift) and 0xFF
            val sum = ((l shr shift) and 0xFF) + ((r shr shift) and 0xFF) +
                ((u shr shift) and 0xFF) + ((d shr shift) and 0xFF)
            val v = cc + amount * (4 * cc - sum)
            return v.toInt().coerceIn(0, 255)
        }

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val c = px[i]
                val l = px[i - 1]
                val r = px[i + 1]
                val u = px[i - w]
                val d = px[i + w]
                out[i] = (0xFF shl 24) or
                    (sc(16, c, l, r, u, d) shl 16) or
                    (sc(8, c, l, r, u, d) shl 8) or
                    sc(0, c, l, r, u, d)
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        liveRecording?.stop()
        videoRecording?.stop()
        ioExecutor.shutdown()
    }

    companion object {
        private const val MAX_ZOOM = 35f
        private const val LIVE_MS = 3000L
        private val YELLOW = Color.parseColor("#FFD60A")
    }
}
