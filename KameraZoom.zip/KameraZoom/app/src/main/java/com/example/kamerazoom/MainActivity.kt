package com.example.kamerazoom

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import com.example.kamerazoom.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.pow

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    // Zoom total yang diminta user (1..MAX_ZOOM).
    // Sebagian dipenuhi zoom hardware kamera, sisanya digital (crop).
    private var userZoom = 1f
    private var minZoom = 1f    // batas bawah zoom (mis. 0.5 kalau ada kamera ultra-wide)
    private var swFactor = 1f   // faktor zoom digital tambahan di atas zoom hardware
    private var telescope = false
    private var touchInPreview = false

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) {
            startCamera()
        } else {
            Toast.makeText(this, "Izin kamera dibutuhkan", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupControls()
        setupGestures()

        val camGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (camGranted) {
            startCamera()
        } else {
            permLauncher.launch(
                arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            )
        }
    }

    // ---------------------------------------------------------------- UI

    private fun setupControls() {
        binding.zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    applyZoom(minZoom * (MAX_ZOOM / minZoom).pow(progress / 1000f), updateSeek = false)
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.shutterButton.setOnClickListener { capture() }
        binding.btnWide.setOnClickListener { applyZoom(minZoom) }
        binding.btnOne.setOnClickListener { applyZoom(1f) }

        binding.telescopeSwitch.setOnCheckedChangeListener { _, on ->
            telescope = on
            if (on) {
                applyZoom(MAX_ZOOM)
                Toast.makeText(
                    this,
                    "Mode Telescope: zoom maks + penajaman hasil foto",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun setupGestures() {
        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    applyZoom(userZoom * detector.scaleFactor)
                    return true
                }
            }
        )
        val tapDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent) = true
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    focusAt(e.x, e.y)
                    return true
                }
            }
        )

        binding.root.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                touchInPreview = ev.y < binding.controls.top
            }
            if (touchInPreview) {
                scaleDetector.onTouchEvent(ev)
                tapDetector.onTouchEvent(ev)
            }
            true
        }
    }

    private fun setStatus(text: String) {
        binding.statusLabel.text = text
        binding.statusLabel.visibility = android.view.View.VISIBLE
        handler.removeCallbacks(hideStatus)
        handler.postDelayed(hideStatus, 2500)
    }

    private val hideStatus = Runnable { binding.statusLabel.visibility = android.view.View.GONE }

    // ---------------------------------------------------------------- Kamera

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val ic = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.FHD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            val vc = VideoCapture.withOutput(recorder)

            provider.unbindAll()
            try {
                camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, ic, vc
                )
                videoCapture = vc
            } catch (e: Exception) {
                // HP tidak mendukung foto + video barengan -> fallback foto saja
                provider.unbindAll()
                camera = provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, ic
                )
                videoCapture = null
                binding.liveSwitch.isChecked = false
                binding.liveSwitch.isEnabled = false
                Toast.makeText(
                    this, "HP ini tidak mendukung mode Live, foto biasa saja", Toast.LENGTH_LONG
                ).show()
            }
            imageCapture = ic

            // Kalau HP mengekspos kamera ultra-wide lewat kamera utama,
            // zoom minimumnya di bawah 1x (biasanya 0.5x - 0.6x)
            val hwMin = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
            minZoom = hwMin.coerceIn(0.4f, 1f)
            binding.btnWide.visibility =
                if (minZoom < 0.95f) android.view.View.VISIBLE else android.view.View.GONE
            binding.btnWide.text = String.format(Locale.US, "%.1fx", minZoom)

            applyZoom(1f)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun applyZoom(total: Float, updateSeek: Boolean = true) {
        userZoom = total.coerceIn(minZoom, MAX_ZOOM)

        val state = camera?.cameraInfo?.zoomState?.value
        val hwMax = state?.maxZoomRatio ?: 1f
        val hwMin = (state?.minZoomRatio ?: 1f).coerceAtMost(hwMax)
        val hw = userZoom.coerceIn(hwMin, hwMax)

        camera?.cameraControl?.setZoomRatio(hw)

        // Sisa zoom di atas kemampuan hardware dilakukan digital
        swFactor = (userZoom / hw).coerceAtLeast(1f)
        binding.previewView.scaleX = swFactor
        binding.previewView.scaleY = swFactor

        val digital = if (swFactor > 1.01f) "  (digital)" else ""
        binding.zoomLabel.text = String.format(Locale.US, "%.1fx%s", userZoom, digital)

        if (updateSeek) {
            binding.zoomSeek.progress =
                (ln(userZoom / minZoom) / ln(MAX_ZOOM / minZoom) * 1000f).toInt()
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pv = binding.previewView
        // Koreksi koordinat sentuh karena preview di-scale (zoom digital)
        val cx = pv.width / 2f
        val cy = pv.height / 2f
        val lx = cx + (x - cx) / swFactor
        val ly = cy + (y - cy) / swFactor
        val point = pv.meteringPointFactory.createPoint(lx, ly)
        val action = FocusMeteringAction.Builder(point)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
    }

    // ---------------------------------------------------------------- Jepret

    private fun capture() {
        val ic = imageCapture ?: return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val live = binding.liveSwitch.isChecked && videoCapture != null
        val sw = swFactor
        val sharpenOn = telescope

        if (live) startLiveClip(stamp)

        ic.takePicture(ioExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    var bmp = image.toBitmap()
                    val rot = image.imageInfo.rotationDegrees
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    if (sw > 1.01f) {
                        val w = (bmp.width / sw).toInt().coerceAtLeast(2)
                        val h = (bmp.height / sw).toInt().coerceAtLeast(2)
                        bmp = Bitmap.createBitmap(
                            bmp, (bmp.width - w) / 2, (bmp.height - h) / 2, w, h
                        )
                    }
                    if (sharpenOn) bmp = sharpen(bmp)
                    savePhoto(bmp, stamp, live)
                } catch (t: Throwable) {
                    runOnUiThread { setStatus("Gagal menyimpan foto") }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { setStatus("Gagal jepret: ${exception.message}") }
            }
        })
    }

    private fun savePhoto(bmp: Bitmap, stamp: String, live: Boolean) {
        val prefix = if (live) "LIVE_" else "IMG_"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$prefix$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/KameraZoom")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            runOnUiThread { setStatus("Gagal menyimpan foto") }
            return
        }
        contentResolver.openOutputStream(uri)?.use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)
        }
        runOnUiThread { if (!live) setStatus("Foto tersimpan ✓") }
    }

    // ---------------------------------------------------------------- Live

    @SuppressLint("MissingPermission")
    private fun startLiveClip(stamp: String) {
        val vc = videoCapture ?: return
        if (recording != null) return

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "LIVE_$stamp")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/KameraZoom")
        }
        val options = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = vc.output.prepareRecording(this, options)
        val audioOk = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (audioOk) pending = pending.withAudioEnabled()

        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            if (event is VideoRecordEvent.Finalize) {
                recording = null
                setStatus(if (event.hasError()) "Klip live gagal" else "Foto live tersimpan ✓")
            }
        }
        setStatus("Merekam live…")
        handler.postDelayed({ recording?.stop() }, LIVE_MS)
    }

    // ---------------------------------------------------------------- Telescope

    /** Penajaman sederhana (laplacian 4 tetangga) supaya hasil zoom tinggi lebih tegas. */
    private fun sharpen(src: Bitmap, amount: Float = 0.7f): Bitmap {
        val w = src.width
        val h = src.height
        if (w < 3 || h < 3) return src

        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val out = px.copyOf()

        fun sc(shift: Int, c: Int, l: Int, r: Int, u: Int, d: Int): Int {
            val cc = (c shr shift) and 0xFF
            val sum = ((l shr shift) and 0xFF) + ((r shr shift) and 0xFF) +
                ((u shr shift) and 0xFF) + ((d shr shift) and 0xFF)
            val v = cc + amount * (4 * cc - sum)
            return v.toInt().coerceIn(0, 255)
        }

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val c = px[i]
                val l = px[i - 1]
                val r = px[i + 1]
                val u = px[i - w]
                val d = px[i + w]
                out[i] = (0xFF shl 24) or
                    (sc(16, c, l, r, u, d) shl 16) or
                    (sc(8, c, l, r, u, d) shl 8) or
                    sc(0, c, l, r, u, d)
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        recording?.stop()
        ioExecutor.shutdown()
    }

    companion object {
        private const val MAX_ZOOM = 20f
        private const val LIVE_MS = 3000L
    }
}
