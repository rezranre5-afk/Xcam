plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.kamerazoom"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.kamerazoom"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    // Dua varian yang bisa terpasang berdampingan di satu HP
    flavorDimensions += "ver"
    productFlavors {
        create("v1") {
            dimension = "ver"
            applicationIdSuffix = ".v1"
            versionNameSuffix = "-v1"
            manifestPlaceholders["appLabel"] = "Kamera v1"
            buildConfigField("boolean", "PRO", "false")
        }
        create("v2") {
            dimension = "ver"
            applicationIdSuffix = ".v2"
            versionNameSuffix = "-v2"
            manifestPlaceholders["appLabel"] = "Kamera v2"
            buildConfigField("boolean", "PRO", "true")
        }
    }
}

dependencies {
    val camerax = "1.3.4"
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    implementation("androidx.camera:camera-core:$camerax")
    implementation("androidx.camera:camera-camera2:$camerax")
    implementation("androidx.camera:camera-lifecycle:$camerax")
    implementation("androidx.camera:camera-video:$camerax")
    implementation("androidx.camera:camera-view:$camerax")
}
