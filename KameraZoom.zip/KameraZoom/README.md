# KameraZoom

Kamera Android sederhana (Kotlin + CameraX):

- **Zoom sampai 20x**: pinch di layar atau geser slider. Zoom hardware dipakai dulu, sisanya digital (crop). Label "(digital)" muncul kalau sudah masuk zoom digital.
- **Zoom 0.5x (ultra-wide)**: tombol 0.5x muncul otomatis kalau HP mengekspos kamera ultra-wide lewat kamera utama. Kalau tidak muncul, HP-mu tidak mendukungnya lewat cara ini.
- **Lensa ultra-wide**: kalau kamera ultra-wide tidak digabung oleh sistem, aplikasi mencoba mendeteksi lensanya langsung. Hanya berhasil kalau HP mengekspos lensa itu ke aplikasi.
- **Preset zoom**: tombol 1x, 2x, 5x, 10x, 20x.
- **Foto Live**: tiap jepret menyimpan foto JPEG + klip video 3 detik yang direkam sesaat setelah foto (`Pictures/KameraZoom` dan `Movies/KameraZoom`). Kalau klip gagal, kode error tampil di layar.
- **Mode Telescope**: zoom langsung ke 20x dan hasil foto dipertajam.
- Tap layar untuk fokus.

## Cara build APK

1. Install **Android Studio** (gratis) di laptop.
2. `File > Open`, pilih folder `KameraZoom` ini. Tunggu Gradle sync selesai (butuh internet, pertama kali agak lama).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Kirim ke HP, buka file-nya, izinkan "install dari sumber tidak dikenal", lalu install.

Alternatif: colok HP (USB debugging aktif) lalu klik tombol Run di Android Studio.

## Batasan

- Zoom digital tidak menambah detail asli, hasilnya tetap lebih pecah di atas zoom hardware HP.
- Klip Live hanya merekam 3 detik **setelah** tombol ditekan (belum ada rekaman sebelum jepret), dan belum memakai crop digital.
- Foto dan klip Live tersimpan sebagai dua file terpisah, belum digabung jadi format Motion Photo.
- Android 10 ke atas (minSdk 29).
