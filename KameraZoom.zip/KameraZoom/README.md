# KameraZoom

Kamera Android (Kotlin + CameraX) dengan tata letak ala kamera iPhone.

## Fitur

- **Foto dan Video**: ganti mode lewat label VIDEO / FOTO di bawah. Di mode video, tombol jepret merah untuk mulai dan berhenti, lengkap dengan timer.
- **Zoom sampai 35x**: pinch di layar atau tap tombol 1x, 2x, 5x, 10x, 20x, 35x. Zoom hardware dipakai dulu, sisanya digital (crop). Label menunjukkan "digital" kalau sudah masuk zoom digital. Di mode video zoom dibatasi sesuai kemampuan hardware.
- **Foto Live**: ikon lingkaran di kanan atas. Tiap jepret menyimpan foto + klip video 3 detik yang direkam sesaat setelah foto (`Pictures/KameraZoom` dan `Movies/KameraZoom`). Kalau klip gagal, kode error tampil di layar.
- **Telescope**: tombol di tengah atas. Zoom langsung ke maksimum dan hasil foto dipertajam.
- **Lensa ultra-wide**: tombol 0.5x muncul otomatis kalau HP mengekspos lensa ultra-wide ke aplikasi.
- **Ganti kamera depan/belakang**, **flash** (lampu senter saat video), tap layar untuk fokus.
- **Thumbnail hasil terakhir** di kiri bawah, tap untuk membuka di galeri.

## Cara build APK

1. Install **Android Studio** di laptop, atau pakai GitHub Actions dari HP (lihat panduan di chat).
2. Android Studio: `File > Open` pilih folder ini, tunggu Gradle sync, lalu `Build > Build APK(s)`.
3. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Batasan

- Zoom digital tidak menambah detail asli, hasilnya tetap pecah di atas zoom hardware HP. Di 35x hasilnya akan sangat kasar.
- Klip Live hanya merekam 3 detik **setelah** tombol ditekan dan belum memakai crop digital.
- Foto dan klip Live tersimpan sebagai dua file terpisah, belum digabung jadi format Motion Photo.
- Android 10 ke atas (minSdk 29).
