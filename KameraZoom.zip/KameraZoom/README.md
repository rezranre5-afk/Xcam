# KameraZoom

Kamera Android (Kotlin + CameraX) dengan tata letak ala kamera iPhone.

## Fitur

- **Mode FOTO / VIDEO / CINEMA**: ganti lewat label di bawah. Di mode video dan cinema, tombol jepret merah untuk mulai dan berhenti, lengkap dengan timer.
- **Stabilizer video**: stabilizer elektronik (EIS) kalau HP mendukung, kalau tidak stabilizer optik (OIS). Label info di layar menunjukkan mana yang aktif, atau menyatakan HP tidak punya stabilizer.
- **CINEMA**: video 24 fps (kalau HP mendukung) dengan stabilizer. Ini bukan blur latar ala iPhone, itu butuh sensor kedalaman atau AI waktu nyata.
- **HD+**: penajaman otomatis + sedikit kontras/warna pada foto. Matikan untuk mendapat JPEG asli dari kamera tanpa diolah ulang.
- **Kualitas**: foto memakai resolusi tertinggi, pengolahan tepi dan noise kualitas tinggi (kalau didukung HP), video bitrate 16 Mbps. Resolusi foto tampil di pesan "tersimpan".
- **Zoom sampai 35x**: pinch atau tombol 1x, 2x, 5x, 10x, 20x, 35x. Zoom hardware dipakai dulu, sisanya digital (crop). Di mode video zoom dibatasi zoom hardware.
- **Foto Live**: ikon lingkaran di kanan atas. Tiap jepret menyimpan foto + klip video 3 detik yang direkam sesaat setelah foto.
- **Telescope**: zoom langsung ke maksimum + penajaman kuat.
- **Lensa ultra-wide**: tombol 0.5x muncul otomatis kalau HP mengekspos lensa ultra-wide.
- Ganti kamera depan/belakang, flash (lampu senter saat video), tap untuk fokus, thumbnail hasil terakhir.

## Dua versi (bisa terpasang berdampingan)

- **Kamera v1**: zoom maksimal 35x, tanpa stabilizer tambahan, tanpa mode Cinema, tanpa HD+, kualitas bawaan CameraX.
- **Kamera v2**: zoom maksimal 50x, stabilizer video, mode Cinema, HD+, resolusi tertinggi, bitrate video lebih tinggi.

Keduanya punya application id berbeda (`.v1` dan `.v2`), jadi bisa dipasang bersamaan. Hanya satu yang bisa memakai kamera pada satu waktu, jadi tutup satu sebelum membuka yang lain. Nama file hasil bertanda `V1` atau `V2` (misal `IMG_V2_...jpg`) supaya mudah dibandingkan di galeri.

## Cara build APK

1. Android Studio: `File > Open` pilih folder ini, tunggu Gradle sync, lalu `Build > Build APK(s)`. Atau pakai GitHub Actions dari HP.
2. APK ada di `app/build/outputs/apk/v1/debug/app-v1-debug.apk` dan `app/build/outputs/apk/v2/debug/app-v2-debug.apk`.

## Batasan

- Zoom digital tidak menambah detail asli. Di 35x hasilnya sangat kasar.
- Stabilizer dan 24 fps bergantung pada HP. Kalau HP tidak mendukung, label info menyatakannya.
- Klip Live hanya merekam 3 detik **setelah** tombol ditekan, tanpa crop digital, dan tersimpan sebagai file terpisah.
- Android 10 ke atas (minSdk 29).
